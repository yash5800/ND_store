<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "matapprove";
$conn = new mysqli($servername, $username, "", "my_database");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Information Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 100%;
            padding: 10px 5px 5px 100px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: list;
            grid-gap: 10px;
            margin-top: 5px;
        }
        
        h1 {
            color: yellow;
            font-family: 'Times New Roman', Times, serif;
            text-align: center;
            font-size: 24px;
            margin-bottom: 10px;
        }

        label {
            font-family: 'Times New Roman', Times, serif;
            font-weight: 600;
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="date"],
        input[type="number"],
        select {
            font-family: 'Times New Roman', Times, serif;
            width: 70%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }


        .button {
            background-color: gray;
            color: black;
            border: 1px solid black;
            padding: 7px;
            cursor: pointer;
            border-radius: 4px;
            height: 40px;
            width: 80px;
            font-weight: bold;
            text-align: center;
        }
        .but{
            grid-column: span 7;
            text-align: center;
            margin-top: 20px;
            margin-bottom: 30px;
            display: flex;
            gap: 15px;
            margin-right: 500px;
        }
        .button:hover{
            color:orange;
        }

        .header {
            background-color: #083e3f;
            padding: 10px;
            color: white;
            text-align: center;
            height: 80px;
        }

        .logo {
            position: absolute;
            top: 6px;
            left: 10px;
            width: 90px;
            height: auto;
        }   
    </style>
</head>

<body>
    <header class="header">
        <img src="gec.jpg" alt="Logo" class="logo">
        <h1>MATERIAL FOR APPROVAL</h1>
    </header>
    <fieldset>
        <div class="container">
            <form action="#" method="POST">
                <label for="authorEditor">Author / Editor :</label>
                <select name="authorEditor" id="authorEditor">
                    <option value="author">Author</option>
                    <option value="editor">Editor</option>
                </select>

                <label for="Name"> Name:</label>
                <input type="text" id="Name" name="Name" required>

                <label for="title">Title :</label>
                <input type="text" id="title" name="title" required>

                <label for="edition">Edition :</label>
                <input type="number" id="edition" name="edition" required>

                <label for="volume">Volumes :</label>
                <input type="number" id="volume" name="volume" min="1" required>
  
                <label for="publisher">Publisher :</label>
                <input type="text" id="publisher" name="publisher" required>

                <label for="placeOfPublication">Place of Publication :</label>
                <input type="text" id="placeOfPublication" name="placeOfPublication">

                <label for="vendorName">Vendor Name :</label>
                <input type="text" id="vendorName" name="vendorName" required>

                <label for="vendorCode">Vendor code :</label>
                <input type="number" id="vendorCode" name="vendorCode">

                <label for="selectMember">Select member :</label>
                <select name="selectMember">
                    <option value="faculty">Faculty</option>
                    <option value="student">Student</option>
                </select>

                <label for="typeofmaterial" required>Type Of Material :</label>
                <select name="typeofmaterial">
                    <option value="books">Books</option>
                    <option value="reference">References</option>
                </select>

                <label for="date">Date :</label>
                <input type="date" id="date" name="date">

                <label for="language">Language :</label>
                <input type="text" id="language" name="language">

                <div class="but">
                    <button class="button">Add New</button>
                    <button name="save" class="button">Save</button>
                    <button class="button">Search</button>
                    <button class="button">List</button>
                    <button class="button">Cancel</button>
                    <a href="acq.html"><button class="button">Close</button></a>
                </div>
            </form>
        </div>
    </fieldset>

    <!-- <fieldset>
        <div class="button-container">
            <button class="button">Add New</button>
            <button class="button">Save</button>
            <button class="button">Search</button>
            <button class="button">List</button>
            <button class="button">Cancel</button>
            <a href="acq.html"><button class="button">Close</button></a>
        </div>
    </fieldset> -->
</body>

</html>

<?php 
       if(isset($_POST['save'])){
        
        $authorEditor = $_POST['authorEditor'];
        $name = $_POST['Name'];
        $date = $_POST['date'];
        $title = $_POST['title'];
        $publisher = $_POST['publisher'];
        $placeOfPublication = $_POST['placeOfPublication'];
        $vendorName = $_POST['vendorName'];
        $vendorCode = $_POST['vendorCode'];
        $edition = $_POST['edition'];
        $language = $_POST['language'];
        $volume = (int)$_POST['volume'];
        $selectMember = $_POST['selectMember'];
        $typeofmaterial = $_POST['typeofmaterial'];
        
        for ($i = 1; $i <= $volume; $i++){
            $sql = "INSERT INTO matapp (authorEditor, name, date, title, publisher, placeOfPublication, vendorName, vendorCode, edition, language, selectMember, typeofmaterial) VALUES ('$authorEditor', '$name', '$date', '$title', '$publisher', '$placeOfPublication', '$vendorName', '$vendorCode', '$edition', '$language', '$selectMember', '$typeofmaterial')";
            if ($conn->query($sql) !== TRUE){
                echo "Error :" . $conn->error;
                exit();
        
            }
        }
        $conn->close();?>
        <script>
            alert('Successfully added');
            window.location.href = 'approval/index.php';
            </script>
    <?php
      exit();
    }