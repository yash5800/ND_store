<?php

$con = new mysqli("localhost", "root", "", "my_database");

if ($con->connect_error) {
    die("Server not found!!");
}

header('Content-Type: application/json');

// Retrieve POST data
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['items'])) {
    $items = $data['items'];

    foreach ($items as $id) {
        // Sanitize ID to prevent SQL injection
        $id = intval($id); // Convert ID to integer
        
        // Fetch data from matapp table
        $result = $con->query("SELECT * FROM matapp WHERE id = $id");

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Escape values to prevent SQL injection
                $authorEditor = $con->real_escape_string($row["authorEditor"]);
                $name = $con->real_escape_string($row["name"]);
                $date = $con->real_escape_string($row['date']);
                $title = $con->real_escape_string($row["title"]);
                $publisher = $con->real_escape_string($row["publisher"]);
                $placeOfPublication = $con->real_escape_string($row["placeOfPublication"]);
                $vendorName = $con->real_escape_string($row["vendorName"]);
                $vendorCode = $con->real_escape_string($row["vendorCode"]);
                $edition = $con->real_escape_string($row["edition"]);
                $language = $con->real_escape_string($row["language"]);
                $selectMember = $con->real_escape_string($row["selectMember"]);
                $typeofmaterial = $con->real_escape_string($row["typeofmaterial"]);

                // Construct SQL query
                $insertQuery = "INSERT INTO lib_book (
                    authorEditor, name, date, title, publisher, placeOfPublication, 
                    vendorName, vendorCode, edition, language, selectMember, typeofmaterial
                ) VALUES (
                    '$authorEditor', '$name', '$date', '$title', '$publisher', '$placeOfPublication',
                    '$vendorName', '$vendorCode', '$edition', '$language', '$selectMember', '$typeofmaterial'
                )";

                // Execute the insert query
                $con->query($insertQuery);

                $con->query("delete from matapp where id = $id");
            }
            $result = $con->query("SELECT * FROM matapp");
            if($result->num_rows > 0){
                  $i =1;
                  while($row = $result->fetch_assoc()) {
                    $con->query("update matapp set id = $i WHERE id =".$row["id"]);
                    $i++;
                  }
            }
        }
    }

    echo json_encode(['status' => 'success', 'received' => $items]);

} else {
    echo json_encode(['status' => 'error', 'message' => 'No items received']);
}

// Close the database connection
$con->close();
?>
