<?php

$con = new mysqli("localhost", "root", "", "my_database");

if ($con->connect_error) {
    die("Server not found!!");
}

header('Content-Type: application/json');

// Retrieve POST data
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['items'])) {
    $items = $data['items'];

    foreach ($items as $id) {
        // Sanitize ID to prevent SQL injection
        $id = intval($id); // Convert ID to integer
        

                $con->query("delete from matapp where id = $id");
    }
    
    $result = $con->query("SELECT * FROM matapp");
    if($result->num_rows > 0){
          $i =1;
          while($row = $result->fetch_assoc()) {
            $con->query("update matapp set id = $i WHERE id =".$row["id"]);
            $i++;
          }
    }
    
    echo json_encode(['status' => 'success', 'received' => $items]);
}

else {
    echo json_encode(['status' => 'error', 'message' => 'No items received']);
}

// Close the database connection
$con->close();
?>
