
document.querySelectorAll(".selector").forEach( checkbox => {
    checkbox.addEventListener("change", function(){
    this.value = this.checked ? 'checked' : 'unchecked';
    updatecount();
})
})

document.getElementById("selectall").addEventListener("change", function(){
    let ischecked = this.checked;   
    this.value = ischecked ? 'checked' : 'unchecked';
    let checkboxs = document.querySelectorAll(".selector");
    checkboxs.forEach( checkbox => {
        checkbox.checked = ischecked;
        checkbox.value = ischecked ? 'checked' : 'unchecked';
    })
    updatecount();
})

function updatecount(){
    let che = 0;
    let unche =0;
    let checkboxs = document.querySelectorAll(".selector");
    checkboxs.forEach(checkbox =>{
        if(checkbox.checked){
            che ++;
        }
        else{
            unche ++;
        }
    })
    document.getElementById("che").innerText = che;
    document.getElementById("unche").innerText = unche;

}

updatecount();

function send(){
    let checkedIds = [];
    document.querySelectorAll('.selector:checked').forEach(checkbox => {
        // Navigate to the row and get the ID value
        let row = checkbox.closest('tr'); // Use closest to find the row
        let id = row.cells[1].querySelector('input[type="text"]').value.trim(); // Get ID from input field
        checkedIds.push(id);
    });

   if(checkedIds.length > 0){
          fetch("approve.php",{
              method: "POST",
              headers:{
                  'Content-Type': 'application/json'
              },
              body: JSON.stringify({items:checkedIds})
          })
          .then(response => response.text())
          .then(data => {
              console.log('succ',data)
              alert('approveed successfully')
              window.location.reload()
          })
          .catch(error => {
              console.error('error')
          });
  }
}

function del(){
    let checkedIds = [];
    document.querySelectorAll('.selector:checked').forEach(checkbox => {
        // Navigate to the row and get the ID value
        let row = checkbox.closest('tr'); // Use closest to find the row
        let id = row.cells[1].querySelector('input[type="text"]').value.trim(); // Get ID from input field
        checkedIds.push(id);
    });

   if(checkedIds.length > 0){
        fetch("reject.php",{
            method: "POST",
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({items:checkedIds})
        })
        .then(response => response.text())
        .then(data => {
            console.log('succ',data)
            alert('Rejected successfully')
            window.location.reload()
        })
        .catch(error => {
            console.error('error')
        });
  }
}