<?php
$con = new mysqli("localhost", "root", "", "my_database");
if ($con->connect_error) {
    die("Server not found!!");
}
$result = $con->query("SELECT * FROM matapp");
if ($result->num_rows > 0) {
    $i = 1;
    while ($row = $result->fetch_assoc()) {
        $con->query("UPDATE matapp SET id = $i WHERE id =" . $row["id"]);
        $i++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending For Approval</title>
    <style>
        * {
            font-family: 'Times New Roman', Times, serif;
        }
        body {
            display: flex;
            justify-content: center;
            flex-direction: column;
            align-items: center;
        }
        .main {
            position: relative;
            margin-top: 10px;
            left: 5px;
            width: 100%;
        }
        .main h1{
            background: linear-gradient(45deg,white,yellow);
            background-clip: text;
            color: transparent;
        }
        .ap {
            margin: 10px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .ap button {
            margin: 5px;
            padding: 11px 13px;
            border-radius: 10px;
            color: white;
            background: #333;
            border: 1px solid black;
            transition: transform 0.3s;
            box-shadow: 3px 3px 10px 1px rgb(0, 0, 0,0.5),
            -3px -3px 10px 1px rgb(255, 255, 255,0.5);
        }
        .ap #apr:hover {
            transform: scale(1.1);
            color: greenyellow;
            border: 2px greenyellow solid;
        }
        .ap #rej:hover {
            transform: scale(1.1);
            color: red;
            border: 2px red solid;
        }
        table {
            margin: 2px 2px 2px 2px;
            border: 1px solid black;
            border-collapse: collapse;
            border-radius: 10px;
            width: 100%;
            margin-right: 30px;
        }
        th {
            background: linear-gradient(to right, pink, red);
            color: white;
        }
        #data:hover {
            border: 5px solid green;
        }
        td, th {
            border: 1px solid black;
            padding: 2px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }
        .status {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        input[type="checkbox"] {
            margin: 10px;
        }
        input {
            font-size: medium;
            height: 10px;
            padding: 10px;
            border: none;
        }
        fieldset {
            display: flex;
            left: 0;
            margin: 0;
            padding: 10px;
            border: none;
            width: 90%;
            align-items: center;
        }
        .inner{
            
            position: sticky;
            background: #333;
            top: 0;
            left: 35%;
            text-align: center;
            height: 50px;
            width: 365px;
            border-radius: 15px;
            margin: 20px;
            font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
            box-shadow: 6px 6px 10px 1px rgb(0, 0, 0,0.6),
                        -6px -6px 10px 1px rgb(255, 255, 255,0.6);
        }
        .inner h1{
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          }
    </style>
</head>
<body>
    <div class="main">
          <div class="inner">
            <h1>Pending For Approval</h1>
          </div>
        <table>
            <tr>
                <th>Select All <br><input style='height:17px;width:17px;' type="checkbox" value="unchecked" id="selectall"></th>
                <th>Id</th>
                <th>AuthorEditor</th>
                <th>Name</th>
                <th>Date</th>
                <th>Title</th>
                <th>Publisher</th>
                <th>Place Of Publication</th>
                <th>Vendor Name</th>
                <th>Vendor Code</th>
                <th>Edition</th>
                <th>Language</th>
                <th>Select Member</th>
                <th>Material Type</th>
            </tr>
            <?php
            $result = $con->query("SELECT * FROM matapp");
            while ($row = $result->fetch_assoc()) {
                echo "<tr id='data'>";
                echo "<td><input class='selector' style='height:17px;width:17px;' type='checkbox' value='unchecked'></td>";
                echo "<td><input type='text' style='width:20px;background: transparent;border:none;outline:none;' value=" . $row["id"] . "></td>";
                echo "<td><input type='text' value=" . $row["authorEditor"] . "></td>";
                echo "<td><input type='text' value=" . $row["name"] . "></td>";
                echo "<td><input type='text' value=" . $row["date"] . "></td>";
                echo "<td><input type='text' value=" . $row["title"] . "></td>";
                echo "<td><input type='text' value=" . $row["publisher"] . "></td>";
                echo "<td><input type='text' value=" . $row["placeOfPublication"] . "></td>";
                echo "<td><input type='text' value=" . $row["vendorName"] . "></td>";
                echo "<td><input type='text' value=" . $row["vendorCode"] . "></td>";
                echo "<td><input type='text' value=" . $row["edition"] . "></td>";
                echo "<td><input type='text' value=" . $row["language"] . "></td>";
                echo "<td><input type='text' value=" . $row["selectMember"] . "></td>";
                echo "<td><select name='ty'>";
                if ($row["typeofmaterial"] == "issue") {
                    echo "<option value='Issue' selected>issue</option>";
                } else {
                    echo "<option value='issue'>issue</option>";
                }
                if ($row["material_type"] == "reference") {
                    echo "<option value='reference' selected>reference</option>";
                } else {
                    echo "<option value='reference'>reference</option>";
                }
                echo "</select></td>";
                echo "</tr>";
            }
            ?>
        </table>
        <fieldset class="field">
        <div class="ap">
            <button id="apr" name="apr" onclick="send()">Approve</button>
            <button id="rej" name="rej" onclick="del()">Reject</button>
        </div>
    
        <div class="status">
            <p>Checked :</p>
            <p id="che" style="color:green;">0</p>
            <p>Unchecked :</p>
            <p id="unche" style="color:#333;">0</p>
        </div>
        </fieldset>
    </div>
    

    <script src="script.js"></script>
</body>
</html>